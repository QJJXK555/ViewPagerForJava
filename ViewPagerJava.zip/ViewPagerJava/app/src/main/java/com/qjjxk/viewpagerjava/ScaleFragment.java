package com.qjjxk.viewpagerjava;

import android.animation.ObjectAnimator;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Random;


public class ScaleFragment extends Fragment {
    ImageView imageViewScale;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_scale, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        imageViewScale = requireView().findViewById(R.id.imgView_scale);
        Log.d("TAG", "皮卡丘");
        imageViewScale.setOnClickListener(v -> {
            float factor = new Random().nextBoolean() ? 0.1f : -0.1f;
            ObjectAnimator.ofFloat(imageViewScale, "scaleX", imageViewScale.getScaleX() + factor).start();
            ObjectAnimator.ofFloat(imageViewScale, "scaleY", imageViewScale.getScaleX() + factor).start();
        });
    }
}